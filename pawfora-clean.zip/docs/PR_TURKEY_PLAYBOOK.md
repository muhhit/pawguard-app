# Türkiye PR & Sosyal Medya Oyun Kitabı

Amaç: Sokak hayvanı krizini çözmeye katkı, güvenli ve etik içerikle duygusal virallik.

İlkeler
- “Kahraman sensin” anlatısı: bireysel katkıyı yücelt, suçlayıcı dil kullanma.
- Etik güvenlik: konum gizliliği, teslim kanıtı, sahte talebe sıfır tolerans.
- Gerçek hikâyeler, gerçek gönüllüler: izinli UGC ve haftalık başarı kolajları.

Taktikler
- 10 günlük çok platformlu plan (Reels/Shorts/TikTok): kurtarma anları, öncesi/sonrası, mahalle alarmı POV.
- WhatsApp köprüsü: paylaşıma hazır metin ve görsel; grup adminlerle uyumlu paylaşımlar.
- STK/Belediye ortak postları: resmi hesaplardan destek; QR poster kampanyaları.
- Medya: haftalık basın bülteni (kaç ilan, kaç buluşma, gönüllü sayısı) + vaka dosyaları.

Risk Yönetimi
- Havrita benzeri kötüye kullanımın önlenmesi: sunucu-tarafı gizlilik, doğrulama, raporlama hattı.
- Tahrik edici/zararlı içerik filtreleri; moderatör ağ.

