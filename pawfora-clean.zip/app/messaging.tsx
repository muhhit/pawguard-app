import MessagingScreen from '@/components/MessagingScreen';

export default MessagingScreen;