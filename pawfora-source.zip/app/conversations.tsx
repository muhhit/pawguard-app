import ConversationsList from '@/components/ConversationsList';

export default ConversationsList;