# UGC ve Viral Döngüler

Hedef: Her ilan → en az 3 paylaşım, her paylaşım → yeni kurulum/geri dönüş.

Bileşenler
- Paylaşım metin şablonları: SocialShare bileşeninde hazır.
- Haftalık başarı kolajı: worker → son 7 gün, buluşmaların kolajı + sayaçlar.
- QR poster: fiziksel dağıtım için şablon (sonraki sprintte görüntü üretimi eklenir).

Ölçüm
- K-faktörü, paylaşım/ilan, paylaşımdan tıklama, kurulumdan aktiflik.
- En çok paylaşan kullanıcılar için ödüller (rozet/premium ay).

